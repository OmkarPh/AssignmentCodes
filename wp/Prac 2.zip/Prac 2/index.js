const signup = (e) => {
    e.preventDefault();
    console.log(e.target.firstName.value)
    alert("Account Created Successfully")
}